# Titan MT5 — prototipe bot DEMO XAUUSD

**Status: eksperimental, belum diuji pada terminal MT5 atau broker HFM yang sebenarnya.** Jangan gunakan akun real. Ini bukan fitur website, belum tersambung ke Vercel/Supabase, dan belum menggunakan berita/fundamental. Tidak ada jaminan profit. Jangan jalankan pada akun atau terminal yang berisi data/posisi sensitif.

Bot ini aplikasi lokal Windows, bukan EA MT4/MT5. Membaca dan (jika diaktifkan) mengirim perintah lewat paket MetaTrader5 ke terminal MT5. Terminal dan PC harus tetap menyala dan terkoneksi. Menutup program tidak otomatis menutup posisi yang sudah terlanjur terbuka; SL/TP yang sudah diterima broker tetap tergantung broker.

## Logika awal eksperimen
- Khusus akun HFM demo mode hedging dan XAUUSD (atau nama simbol HFM yang diset manual); akun real dan netting ditolak. Tidak otomatis mendukung MT4.
- ORB terinspirasi dari `trader-entry` di https://github.com/Jakeschincariol/day-trader-skill (MIT, Copyright 2026 Jake Schincariol); adaptasi sendiri. Paket skill asli berfokus saham AS, data Yahoo dan Alpaca. Ini tidak memasang/menjalankan keseluruhan skill dan bukan strategi yang terbukti untuk emas.
- Range observasi 09:30–09:45 waktu New York dengan candle M5. Ketika candle M5 yang baru selesai ditutup di atas range high, bot boleh mengirim maksimal satu BUY pada candle itu. Jam ini adalah acuan eksperimen, bukan jam resmi pembukaan pasar emas.
- Buy memakai SL di tengah range dan TP sekitar 2 kali jarak entry ke SL (dibulatkan ke tick). Bot juga mencoba menutup posisi miliknya jika estimasi profit setelah biaya entry dan estimasi biaya exit sudah positif. TP 2R adalah order cadangan: posisi dapat dicoba ditutup lebih awal. Penutupan pada profit TIDAK dijamin: estimasi komisi dapat salah, slippage, spread, volatilitas, koneksi, atau penolakan broker bisa mengubah hasil menjadi rugi.
- Aturan stop dan target mungkin tidak cocok untuk XAUUSD; tak ada pengujian profitabilitas. Berita ekonomi / fundamental tidak tersedia. Bot ini BUKAN bot berita, tidak punya filter FOMC, CPI, NFP, dan sejenisnya.
- Membatasi maksimal 20 posisi terbuka di akun, maksimum perkiraan risiko setiap order 0,5% saldo, risiko gabungan posisi dan order baru 1% saldo, serta mencegah order baru setelah penurunan equity relatif ke saldo awal hari New York mendekati 1%. Saldo awal hari direkonstruksi dari histori transaksi MT5; histori tak tersedia atau penyesuaian saldo hari itu memblokir order baru. Batas diperiksa saat proses berjalan, bukan jaminan batas kerugian. Kejatuhan harga, gap, spread, slippage, biaya, disconnect, transaksi lain atau kegagalan broker dapat menyebabkan rugi lebih besar. Jika minimum lot terlalu besar bot menolak order.
- Memblokir order baru bila ada pending order, posisi tanpa SL, data stale, spread terlalu besar, risiko/margin tidak bisa diverifikasi, hasil order tidak pasti, atau syarat broker gagal. Hanya menutup posisi bertanda milik bot sendiri. Pembatasan risiko tidak mencegah transaksi yang dibuat aplikasi lain dan tidak otomatis menutup semua posisi saat batas harian tercapai.
- Gunakan satu proses bot di satu komputer per akun; state dan lock hanya lokal, bukan pengunci global. Jangan jalankan bot yang sama di komputer lain. `bot-state.sqlite3` menyimpan hash akun dan status intent lokal untuk mengurangi order duplikat. Jangan hapus/ubah file state. Jika hasil order tidak pasti, berhenti dan periksa riwayat di MT5 secara manual sebelum melakukan apa pun.

## Setup Windows (bukan untuk akun real)
1. Buka MT5 HFM, login manual ke akun **demo hedging**, pastikan tersambung. Jangan masukkan password broker ke program atau chat. Waktu Windows harus benar.
2. Ekstrak paket ini. Buka PowerShell dari folder hasil ekstrak.
3. Pasang dependensi:

   py -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt

4. Pertama jalankan tes offline tanpa order:

   .\.venv\Scripts\python.exe -m unittest -v test_bot

Tes hanya menggunakan broker palsu (mock); bukan verifikasi koneksi, harga, eksekusi HFM, maupun strategi.
5. `bot.py` **tidak menjalankan order secara default**. Pengaktifan eksplisit dengan `--enable-demo-trading` akan langsung memberi program izin untuk mencoba membuka dan menutup order pada akun demo yang aktif. Karena belum diuji di HFM, jangan aktifkan sebelum pengujian bersama saat pasar buka. Simbol di Market Watch bisa punya suffix dan harus dipakai persis. Fitur AutoTrading/izin terminal harus sesuai dan broker dapat menolak perintah.
6. Berhenti: Ctrl+C. Hentikan dan cek terminal jika ada pesan hasil tidak pasti, sebelum mengulangi. Jangan menghapus bot-state.sqlite3 untuk menyiasati penguncian. Jika program/crash meninggalkan `bot.lock`, jangan hapus sebelum memastikan tidak ada bot yang masih berjalan dan semua order direkonsiliasi di MT5.

Tidak menyimpan password, tidak mengunggah data akun ke website, dan tidak menarik uang dari broker. Jangan mengirimkan nomor login, password atau kunci API lewat chat.
